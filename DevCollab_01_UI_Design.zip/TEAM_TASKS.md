# Student 1 — UI/UX and responsive frontend
Own public/index.html and public/styles.css.
Implement a real improvement: refine responsive navigation, improve accessibility labels, and test narrow + desktop widths.
Commit the changes you personally make on branch feature/ui-responsive; attach screenshots.

These files are AI-assisted starter code. Copying unchanged files is not evidence of independent coding. Review, understand, modify, test and disclose AI assistance.
